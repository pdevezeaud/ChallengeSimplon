var ordi;
//choix du joueur
var choixUtilisateur; // = prompt("Choisissez : pierre ?, feuille ?, ciseaux ?");

/*================= jquery     =============*/
function selection(){
	$(document).ready(function(){
    $("#pierre").click(function(){
      choixUtilisateur =  $(this).find("#pierre").attr("alt");
    });
}); ;
}
/* ==================== fin jquery ================== */


/*============== choix de l'ordinateur =================*/
ordi = Math.floor((Math.random() * 3) + 1);
if (ordi == 1) {
	ordi = "pierre";
	
} else if (ordi == 2) {
	ordi = "feuille";
} else {
	ordi = "ciseaux";
}

var choix1 = choixUtilisateur;
var choix2 = ordi;

/* ================== fonction de comparaison ================ */
var comparer = function (choix1, choix2) {
	if (choix1 === choix2) {
		return "Egalité !";
	}

	else if (choix1 === "pierre") {
		if (choix2 === "ciseaux") {
			return "pierre gagne";
		} else {
			return "feuille gagne";
		}
	}
	else if (choix1 === "feuille") {
		if (choix2 === "pierre") {
			return "feuille gagne";
		} else {
			return "ciseaux gagne";
		}
	}
	else {
		if (choix2 === "pierre") {
			return "pierre gagne";
		} else {
			return "ciseaux gagne";
		}
	}

};
console.log(comparer(choixUtilisateur, ordi));
	

	
	
	
